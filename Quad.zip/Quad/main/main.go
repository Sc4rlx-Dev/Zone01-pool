package main

import "piscine"

func main() {
	piscine.QuadA(6,7)
}